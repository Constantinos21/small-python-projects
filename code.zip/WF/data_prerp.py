####################### DATA PREP IS ALSO PART OF MAIN.IPYNB #############################

import pandas as pd
import os 

def process_suicide_data(file_name_2014, file_name_2020):
    # Construct file paths based on the current working directory
    current_dir = os.getcwd()
    file_path_2014_2019 = os.path.join(current_dir, 'data', file_name_2014)
    file_path_2020_2023 = os.path.join(current_dir, 'data', file_name_2020)

    # Load datasets
    data2014 = pd.read_csv(file_path_2014_2019)
    data2020 = pd.read_csv(file_path_2020_2023)
    
    # Identify columns related to suicide
    suicide_col_2014_2019 = [col for col in data2014.columns if 'suicide' in col.lower() or 'self-harm' in col.lower()]
    suicide_col_2020_2023 = "Intentional Self-Harm (Suicide)"
    suicide_col_2014_2019 = suicide_col_2014_2019[0] if suicide_col_2014_2019 else None

    # Selecting relevant columns 
    columns_to_select = ['Year', 'Month', suicide_col_2014_2019] if suicide_col_2014_2019 else ['Year', 'Month']
    data_2014_2019_selected = data2014[columns_to_select]
    data_2020_2023_selected = data2020[['Year', 'Month', suicide_col_2020_2023]]

    # Renaming columns for consistency
    data_2014_2019_selected.rename(columns={suicide_col_2014_2019: 'Suicides'}, inplace=True)
    data_2020_2023_selected.rename(columns={suicide_col_2020_2023: 'Suicides'}, inplace=True)

    # Combine and clean data
    combined_data = pd.concat([data_2014_2019_selected, data_2020_2023_selected])
    combined_data.dropna(subset=['Suicides'], inplace=True)

    # Group by Year and sum the Suicides
    annual_suicides = combined_data.groupby('Year')['Suicides'].sum().reset_index()
    return annual_suicides
    
    # # Save the aggregated data to CSV
    # annual_suicides.to_csv(output_file_path, index=False)
    
    # return data2014, data2020, output_file_path


def prepare_the_NCH(NCH_file):

    try:
        current_dir = os.getcwd()
        file_path_NCH = os.path.join(current_dir, 'data', NCH_file)
        
        data = pd.read_csv(file_path_NCH)
        suicide_col_name = "Intentional self-harm (suicide) (*U03,X60-X84,Y87.0)"

        # Filter data for the specified cause and years
        data_selected = data[(data['113 Cause Name'] == suicide_col_name) & (data['Year'].between(2000, 2014)) & (data['State'] == 'United States')]
        
        data_to_save = data_selected[['Year', 'Deaths']]
        data_to_save = data_to_save.rename(columns={'Deaths': 'Suicides'})

        # Sort by Year
        data_to_save.sort_values(by=['Year'], inplace=True)
        return data_to_save
        
        # # Save combined data to CSV
        # data_to_save.to_csv(output_file_path, index=False)
        # print("Data saved to:", output_file_path)

    except Exception as e:
        print("An error occurred:", e)


# def process_detailed_suicide_data(file_path):
#     # Read the CSV file
#     current_dir = os.getcwd()
#     file_path_detailed = os.path.join(current_dir, 'data', file_path)
#     data = pd.read_csv(file_path_detailed)

#     # Filter for intentional self-harm (suicide)
#     suicide_filter = 'Intentional self-harm (suicide)'  
#     suicide_data = data[data['Cause_Desc'] == suicide_filter]

#     # Select relevant rows
#     columns_of_interest = ['Year', 'Strata', 'Strata_Name', 'Count']
#     suicide_data_selected = suicide_data[columns_of_interest]

#     # Group certain ethnicities into 'Minorities'
#     minorities = ['American Indian/Alaska Native', 'Hawaiian/Pacific Islander', 'Multi-Race', 'Other/Unknown']
#     suicide_data_selected['Strata_Name'] = suicide_data_selected['Strata_Name'].replace(minorities, 'Minorities')

#     # Fill empty values with 0.0
#     suicide_data_selected['Count'] = suicide_data_selected['Count'].fillna(0.0)

#     gender_data = suicide_data_selected[suicide_data_selected['Strata_Name'].isin(['Female', 'Male'])]
#     gender_data = gender_data.groupby(['Year', 'Strata_Name']).sum().reset_index()
    
#     # Ethnicity data processing
#     ethnicity_data = suicide_data_selected[~suicide_data_selected['Strata_Name'].isin(['Female', 'Male', 'Total Population', 'Nonbinary/Unknown'])]
#     # Aggregate counts by year for the 'Minorities' category
#     ethnicity_data = ethnicity_data.groupby(['Year', 'Strata_Name']).sum().reset_index()

#     # Remove duplicates
#     # gender_data = gender_data.drop_duplicates(subset=['Year', 'Strata', 'Strata_Name'])
    

#     return gender_data, ethnicity_data

def process_detailed_suicide_data(file_path):
    # Read the CSV file
    current_dir = os.getcwd()
    file_path_detailed = os.path.join(current_dir, 'data', file_path)
    data = pd.read_csv(file_path_detailed)

    # Filter for intentional self-harm (suicide)
    suicide_filter = 'Intentional self-harm (suicide)'  
    suicide_data = data[data['Cause_Desc'] == suicide_filter]

    # Select relevant rows
    columns_of_interest = ['Year', 'Strata', 'Strata_Name', 'Count']
    suicide_data_selected = suicide_data[columns_of_interest]
    
    return suicide_data_selected


def new_data_set(file_path):
    
    current_dir = os.getcwd()
    file_path_detailed = os.path.join(current_dir, 'data', file_path)
    data = pd.read_csv(file_path_detailed)
    
    minorities = ['American Indian and Alaska Native', 'Native Hawaiian and Other Pacific Islander', 'Two or more races']
    data['Minorities'] = data[minorities].sum(axis=1)
    
    data.drop(columns=minorities, inplace=True)
    
    data["Total"] = data.iloc[:, 1:].sum(axis=1)
    data.rename(columns={'Black or African American': 'Black'}, inplace=True)
    
    data = data.round(2)
    
    return data


# if __name__ == '__main__':
#     # detailed_file = '20231206_deaths_final_2014_2022_state_year_sup.csv'
#     filee = 'Untitled spreadsheet - Sheet1.csv'
#     print(new_data_set(filee))

#     # Process data and get DataFrames
#     # gender_data, ethnicity_data = process_detailed_suicide_data(detailed_file)
#     dataa = new_data_set(filee)

#     # Save the DataFrames to separate CSV files
#     # gender_output_name = 'people.csv'
#     # ethnicity_output_name = 'ethnicity.csv'
#     ethnicity_output = 'ethincity_total.csv'
#     # gender_data.to_csv(gender_output_name, index=False)
#     # ethnicity_data.to_csv(ethnicity_output_name, index=False)
#     dataa.to_csv(ethnicity_output, index=False)

#     # print(f"Gender data saved to: {gender_output_name}")
#     # print(f"Ethnicity data saved to: {ethnicity_output_name}")
#     print(f"Ethnicity data saved to: {ethnicity_output}")
    

if __name__ == '__main__':    
    file_2014_name = 'Monthly_Counts_of_Deaths_by_Select_Causes__2014-2019.csv'
    file_2020_name = 'Monthly_Provisional_Counts_of_Deaths_by_Select_Causes__2020-2023.csv'
    NCH = 'NCHS_-_Leading_Causes_of_Death__United_States.csv'
    detailed_file = '20231206_deaths_final_2014_2022_state_year_sup.csv'
    filee = 'Untitled spreadsheet - Sheet1.csv'

    # Process data and get DataFrames
    suicide_data = process_suicide_data(file_2014_name, file_2020_name)
    NCH_data = prepare_the_NCH(NCH)
    detailed_suicide_data = process_detailed_suicide_data(detailed_file)
    dataa = new_data_set(filee)

    # Combine the DataFrames
    combined_data = pd.concat([suicide_data, NCH_data], axis=0)
    combined_data = combined_data[combined_data['Year'] != 2023]
    combined_data.sort_values(by='Year', inplace = True)
    combined_data.drop_duplicates(subset='Year', keep='first', inplace=True)

    # Save the combined DataFrame to a single CSV
    combined_output_name = 'combined_suicide_data.csv'
    detailed_output_name = 'detailed_csv.csv'
    ethnicity_output = 'ethincity_total.csv'
    combined_data.to_csv(combined_output_name, index=False)
    detailed_suicide_data.to_csv(detailed_output_name, index=False)
    dataa.to_csv(ethnicity_output, index=False)
    print(f"Combined data saved to: {combined_output_name}, Detailed data saved to: {detailed_output_name}, and Ethnicity data saved to: {ethnicity_output}")

